
package Figuras;

import java.util.logging.Logger;

class Circulo {
    
    private int XCir=0,YCir=0,AnchoCir=0,AltoCir=0,ColorCir=0;

    public Circulo(int Xcir,int YCir,int AnchoCir,int AltoCir,int ColorCir ) {
        
        
        
    }

    public int getXCir() {
        return XCir;
    }

    public void setXCir(int XCir) {
        this.XCir = XCir;
    }

    public int getYCir() {
        return YCir;
    }

    public void setYCir(int YCir) {
        this.YCir = YCir;
    }

    public int getAnchoCir() {
        return AnchoCir;
    }

    public void setAnchoCir(int AnchoCir) {
        this.AnchoCir = AnchoCir;
    }

    public int getAltoCir() {
        return AltoCir;
    }

    public void setAltoCir(int AltoCir) {
        this.AltoCir = AltoCir;
    }

    public int getColorCir() {
        return ColorCir;
    }

    public void setColorCir(int ColorCir) {
        this.ColorCir = ColorCir;
    }
    
    
    
    
    
}
