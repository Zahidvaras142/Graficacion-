
package Figuras;

class Cuadrado {
    int XCua,YCua,AnchoCua,AltoCua,ColorCua;

    public Cuadrado(int XCua, int YCua, int AnchoCua, int AltoCua, int ColorCua) {
        this.XCua = XCua;
        this.YCua = YCua;
        this.AnchoCua = AnchoCua;
        this.AltoCua = AltoCua;
        this.ColorCua = ColorCua;
    }

    public int getXCua() {
        return XCua;
    }

    public void setXCua(int XCua) {
        this.XCua = XCua;
    }

    public int getYCua() {
        return YCua;
    }

    public void setYCua(int YCua) {
        this.YCua = YCua;
    }

    public int getAnchoCua() {
        return AnchoCua;
    }

    public void setAnchoCua(int AnchoCua) {
        this.AnchoCua = AnchoCua;
    }

    public int getAltoCua() {
        return AltoCua;
    }

    public void setAltoCua(int AltoCua) {
        this.AltoCua = AltoCua;
    }

    public int getColorCua() {
        return ColorCua;
    }

    public void setColorCua(int ColorCua) {
        this.ColorCua = ColorCua;
    }
    
    
}
